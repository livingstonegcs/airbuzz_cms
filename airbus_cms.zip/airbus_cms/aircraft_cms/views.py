from django.shortcuts import render
from django.http import JsonResponse
import pymysql

##GLOBAL VALUES
sql_queries_dict = {}
sql_queries_ = []
deferred = True

def home(request):
    return render(request, 'aircraft_cms/landingpage.html')


# Create your views here.

def generic_update_table_directly(conn, table_name, request, deferred):
    sql_queries  = parse_update_request_and_make_sql_query(table_name, request)

    #if the table doesnot have any queries previously
    if table_name not in sql_queries_dict:
        sql_queries_dict[table_name] = sql_queries
    else:
        sql_queries_dict[table_name].extend(sql_queries)
    try:
        with conn.cursor() as cursor:
            for sql in sql_queries:
                print(sql)
                #cursor.execute("commit;")
                cursor.execute(sql)
                if deferred!=True:
                    cursor.execute("commit;")
    except:
        print("ERROR IN UPDATION")

def tableJSON(request, table_name):
    conn = connect_to_db()
    if request.method == "POST":
        print(request.POST)
        generic_update_table_directly(conn, table_name, request, deferred=True)
        print("UPDATE Successful tableJSON")

    return fetchall_from_table(conn, table_name)

def generic_table(request):
    all_tables = ['iocl_demo', 'iocl_demo2','iocl_demo3','data']
    table_list = ['iocl_demo', 'iocl_demo2','iocl_demo3','data']
    if request.method == "POST":
        if request.POST.getlist('table_list'):
            table_list = request.POST.getlist('table_list')
            print("TABLE_LIST", table_list, "\n")
        if 'update_database' in request.POST:
            generic_update_database(request)

    sql_queries_dict.clear()
    return render(request, 'aircraft_cms/generic_tables.html', {"table_details":generic_tables(table_list),"all_tables":all_tables})#,'tc_vessel'])})

def generic_tables(table_names=['iocl_demo']):
    conn = connect_to_db()
    result = None
    table_dict = {}
    for table in table_names:
        with conn.cursor() as cursor:
            sql = "describe {} ;".format(table)
            cursor.execute(sql)
            result = cursor.fetchall()
            print("RESULT:::", result)
            if result:
                columns_type = {}
                for each in result:
                    columns_type[each['Field']] = each['Type']
                table_dict[table] = columns_type
    print(table_dict)
    return table_dict

def generic_update_database(request):
    if deferred==True:
        for each in sql_queries_dict:
            sql_queries = sql_queries_dict[each]
            if sql_queries:
                conn = connect_to_db()
                with conn.cursor() as cursor:
                    for sql in sql_queries_:
                        cursor.execute(sql)
                        cursor.execute("commit;");



#2
def plan(request):
    if request.method == "POST":
        if 'update_database' in request.POST:
            update_database(request)

    sql_queries_.clear()
    return render(request, 'aircraft_cms/planpage2.html')

def update_database(request):
    if deferred==True:
        if sql_queries_:
            conn = connect_to_db()
            with conn.cursor() as cursor:
                for sql in sql_queries_:
                    cursor.execute(sql)
                    cursor.execute("commit;");


#2.1
def planJSON(request):
    conn = connect_to_db()
    table='iocl_demo'
    if request.method == "POST":
        print(request.POST)
        print("PLAN JSON : POST")
        update_table_directly(conn, table, request, deferred=True)
        print(sql_queries_, "dot....")
        print("UPDATE Successful")
    print("PLAN JSON : GET")
    return fetchall_from_table(conn, table)

#UPDATES TABLE
def update_table_directly(conn, table_name, request, deferred):
    sql_queries  = parse_update_request_and_make_sql_query(table_name, request)
    try:
        with conn.cursor() as cursor:
            for sql in sql_queries:
                print(sql)
                #cursor.execute("commit;")
                cursor.execute(sql)
                if deferred!=True:
                    cursor.execute("commit;")
    except:
        print("ERROR IN UPDATION")

def connect_to_db():
    try:
        conn = pymysql.connect(host='localhost',
                                     user='iocluser',
                                     password='',
                                     db='iocldb',
                                     charset='utf8mb4',
                                     cursorclass=pymysql.cursors.DictCursor)
        print("Connection Successful")
        return conn
    except Exception as err:
        print("Could not connect to Mysql Database")
        PrintException()

#THIS PARSING IS for datatable.editor AJAX REQUEST
def parse_update_request_and_make_sql_query(table_name, request):
    sql_queries = []
    ##EACH KEY IS OF THE FORM 'data[row_id][field_name]'
    for each_key in request.POST:
        if each_key!='action':
            ###SPLIT W.R.T  '[' AND ']'
            each_update = each_key.split('[')
            temp = []
            for token_ in each_update:
                temp.extend(token_.split(']'))
            ###NON EMPTY TOKEN
            temp = [token_ for token_ in temp if token_!='' and token_!='data']

            row_id = temp[0]
            field_name = temp[1]
            value = str(request.POST[each_key])
            sql = "UPDATE {} SET {}='{}' WHERE id={};".format(table_name, field_name, value, row_id)
            sql_queries.append(sql)
    sql_queries_.extend(sql_queries)
    return sql_queries


def fetchall_from_table(conn, table_name):
    try:
        with conn.cursor() as cursor:
            sql = "select * from {}".format(table_name)
            cursor.execute(sql)
            result = cursor.fetchall()
            print(result,"RRRRRRRRRRRRRRR")
            #return HttpResponse(result)
            return JsonResponse({"data":result})
    except:
        print("ERROR IN FETCHING FROM TABLE "+table_name)
        return JsonResponse({"data":[]})
