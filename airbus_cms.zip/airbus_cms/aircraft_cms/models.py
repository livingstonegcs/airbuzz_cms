from django.db import models

class Headlines(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length = 100)
    content = models.TextField()
    pub_date = models.DateField("DD-MM-YYYY")

class Aircraft(models.Model):
    ##To identify the aircraft
    id = models.AutoField(primary_key=True)
    msn = models.IntegerField()
    flight_no = models.IntegerField(unique=True)
    aircraft_model = models.CharField(max_length = 10)

    ##Properties of aircraft
    gross_weight = models.DecimalField(max_digits=10, decimal_places=2)
    atmospheric_pressure = models.DecimalField(max_digits=10, decimal_places=2)
    fuel_capacity_on_left_Wing = models.DecimalField(max_digits=10, decimal_places=2)
    fuel_capacity_on_right_Wing = models.DecimalField(max_digits=10, decimal_places=2)
    fuel_quantity_on_left_Wing = models.DecimalField(max_digits=10, decimal_places=2)
    fuel_quantity_on_right_Wing = models.DecimalField(max_digits=10, decimal_places=2)
    max_altitude = models.DecimalField(max_digits=10, decimal_places=2)

class Schedules(models.Model):
    id = models.AutoField(primary_key = True)
    flight_no = models.ForeignKey(Aircraft, to_field='flight_no',  on_delete=models.CASCADE)
    from_date = models.DateField("DD-MM-YYYY")
    to_date = models.DateField("DD-MM-YYYY")
