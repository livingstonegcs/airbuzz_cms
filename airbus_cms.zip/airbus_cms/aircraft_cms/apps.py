from django.apps import AppConfig

app_name = 'aircraft_cms'
class AircraftCmsConfig(AppConfig):
    name = 'aircraft_cms'
