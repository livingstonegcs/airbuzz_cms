$.ajaxSetup({
     beforeSend: function(xhr, settings) {
         function getCookie(name) {
             var cookieValue = null;
             if (document.cookie && document.cookie != '') {
                 var cookies = document.cookie.split(';');
                 for (var i = 0; i < cookies.length; i++) {
                     var cookie = jQuery.trim(cookies[i]);
                     // Does this cookie string begin with the name we want?
                     if (cookie.substring(0, name.length + 1) == (name + '=')) {
                         cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                         break;
                     }
                 }
             }
             return cookieValue;
         }
         if (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url))) {
             // Only send the token to relative URLs i.e. locally.
             xhr.setRequestHeader("X-CSRFToken", getCookie('csrftoken'));
         }
     }
});

var editor; // use a global for the submit and return data rendering in the {{key}}s
$(document).ready(function() {
    editor = new $.fn.dataTable.Editor( {
        ajax: {
              edit: {
                    type: 'POST',
                    url:  "{%url 'iocl:tableJSON' key %}"
              }
          },
        idSrc: "id",
        table: "#{{key}}",
        fields: [
                  {% for k,v in value.items %}
                  {
                      label: "{{k|capfirst}}",
                      name: "{{k}}" {%ifequal v "date" %},
                      type: "datetime"
                      {%endifequal%}
                  },
                  {%endfor%}
                ]
    } );
    //
    $('#{{key}}').DataTable ( {
        dom: "Bfrtip",
        ajax: "{% url 'iocl:tableJSON' key %}",

        columns: [
            {% for k,v in value.items %}{%ifnotequal forloop.counter 1%},{%endifnotequal%}
            { data: "{{k}}"}
            {%endfor%}
        ],
        select: true,
        buttons: [
            { extend: "edit" ,
              text: '<span class="glyphicon glyphicon-pencil pull-left"></span>Edit</button>',
              className: 'btn btn-primary',
              editor: editor}
        ]
    } );
} );
