from django.urls import path
from django.conf.urls.static import static
from django.conf import settings

from . import views
app_name = 'aircraft_cms'

urlpatterns = [
    path('', views.home, name = 'home'),
    path('plan', views.plan, name = 'plan'),
    path('planJSON', views.planJSON, name = 'planJSON'),
    path('generic_table', views.generic_table, name="generic_table"),
    path('tableJSON/<slug:table_name>',views.tableJSON, name="tableJSON"),
] + static(settings.STATIC_URL, document_root = settings.STATIC_ROOT)
